/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

//Program to implement stack operations using Singly Linked List.

#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include <string.h>

struct stack 
{
    int data;
    struct stack *next;
};

struct stack *NN, *top=NULL, *start=NULL, *temp, *temp2;

void push()
{
    int val;
    int ch;

    printf("Enter data: ");
    scanf("%d", &val);
    NN=(struct stack *)malloc(sizeof(struct stack *));
    NN->data=val;
    NN->next=NULL;
    if (top==NULL)
    {
        start=top=NN;
    }
    else
    {
        top->next=NN;
        top=NN;
    }
}

int pop()
{
    if (start==NULL)
    {
        printf("The stack is empty\n");
    }
    else
    {
        temp=start;
        while (temp!=top)
        {
            temp2=temp;
            temp=temp->next;
        }
        top=temp2;
        printf("Number popped from the stack is: %d\n", temp->data);
        free(temp);
    }
}

void display()
{
    int i;
    if (top==NULL)
    {
        printf("Stack is empty\n");
    }
    else
    {
        temp=start;
        while (temp!=top)
        {
            printf("%d -> ", temp->data);
            temp=temp->next;
        }
        printf("%d -> ",top->data);
        printf("\n");
    }
}

void main()
{
    int choice, ch;
    do
    {
        printf("-----Main Menu-----\n");
        printf("1. Push\n");
        printf("2. Pop\n");
        printf("3. Display\n");
        printf("4. Exit\n");
        printf("Enter your choice here: ");
        scanf("%d", &choice);
        switch (choice)
        {
            case 1:
            {
                int chpush;
                do
                {
                    push();
                    printf("Press 1 to push more elements: ");
                    scanf("%d", &chpush);
                }while(chpush==1);
                break;
            }
            case 2:
            {
                pop();
                break;
            }
            case 3:
            {
                display();
                break;
            }
            case 4:
            {
                printf("The program has ended\n");
                exit(0);
            }
            default:
            {
                printf("Please enter a valid choice\n");
                break;
            }
        }
        printf("Press 1 to continue: ");
        scanf("%d", &ch);
    }while (ch==1);
}



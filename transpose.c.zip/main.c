/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
//Program to find transpose of a matrix

#include <stdio.h>

void main()
{
    int r,c, arr[20][20];
    printf("Enter the number of rows: ");
    scanf("%d", &r);
    printf("Enter the number of columns: ");
    scanf("%d", &c);
    printf("Enter the elements of the array:\n");
    int i,j;
    for(i=0;i<r;i++)
    {
        for(j=0;j<c;j++)
        {
            printf("a[%d][%d]= ",i,j);
            scanf("%d", &arr[i][j]);
        }
    }
    printf("The entered array is:\n");
    for(i=0;i<r;i++)
    {
        for(j=0;j<c;j++)
        {
            printf("%d\t", arr[i][j]);
        }
        printf("\n");
    }
    //Finding transpose of the matrix
    int m,n,arr2[20][20];
    printf("Transpose of the above array is:\n");
    for(m=0;m<c;m++)
    {
        for(n=0;n<r;n++)
        {
            arr2[m][n]=arr[n][m];
        }
    }
    for(m=0;m<c;m++)
    {
        for(n=0;n<r;n++)
        {
            printf("%d\t",arr2[m][n]);
        }
        printf("\n");
    }
}

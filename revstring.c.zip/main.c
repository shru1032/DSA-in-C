/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/
//Program to reverse a string 

#include <stdio.h>
#include <conio.h>
#include <string.h>
#define MAX 100
int top=-1;
void push(char stack[], char val);
char pop(char stack[]);
void main()
{
    char stack[MAX];
    char str[MAX];
    printf("\nEnter the string here: ");
    gets(str);
    int i=0;
    for(i=0;i<strlen(str);i++)
    {
        push(stack,str[i]);
    }
    printf("The reversed string is: \n");
    int j;
    while(top!=-1)
    {
        pop(stack);
    }
}
void push(char stack[], char val)
{
    if (top==(MAX-1))
    {
        printf("Stack Overflow\n");
    }
    else 
    {
        top=top+1;
        stack[top]=val;
    }
}
char pop(char stack[])
{
    if (top==-1)
    {
        printf("Stack Undeflow\n");
    }
    else
    {
        printf("%c",stack[top]);
        top=top-1;
    }
}




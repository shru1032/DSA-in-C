/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/
//Merging 2 arrays
#include <stdio.h>
#include <conio.h>
void main()
{
    int arr1[10],i,n1;
    printf("Enter the number of elements in the first array: ");
    scanf("%d", &n1);
    printf("Enter the elements of the first array:\n");
    for(i=0;i<n1;i++)
    {
        printf("Enter the element-%d of the array: ", i+1);
        scanf("%d", &arr1[i]);
    }
    printf("The first array is:\n ");
    for(i=0;i<n1;i++)
    {
        printf("%d\t", arr1[i]);
    }
    int arr2[10],j,n2;
    printf("\nEnter the number of elements in the second array: ");
    scanf("%d", &n2);
    printf("Enter the elements of the second array:\n");
    for(j=0;j<n2;j++)
    {
        printf("Enter the element-%d of the array: ", j+1);
        scanf("%d", &arr2[j]);
    }
    printf("The second array is:\n ");
    for(j=0;j<n2;j++)
    {
        printf("%d\t", arr2[j]);
    }
    int arr3[100],k;
    for(k=0;k<n1;k++)
    {
        arr3[k]=arr1[k];
    }
    int l;
    for(k=n1;k<n1+n2;k++)
    {
            arr3[k]=arr2[k-n1];
    }
    int m;
    printf("\nMerging the arrays 1 and 2:\n");
    for(m=0;m<n1+n2;m++)
    {
        printf("%d\t", arr3[m]);
    }
}
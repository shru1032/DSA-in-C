/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/
//Stack using arrays

#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#define MAX 100

int stk[MAX],top=-1;
void push(int stk[], int val);
int pop(int stk[]);
void display(int stk[]);

int main()
{
    int val,ch;
    char x;
    do
    {
        printf("*****Main Menu*****\n");
        printf("1. Push\n");
        printf("2. Pop\n");
        printf("3. Display\n");
        printf("4. Exit\n");
        printf("Enter your choice here: ");
        scanf("%d", &ch);
        switch(ch)
        {
            case 1:
            {
                printf("Enter the number to be pushed: ");
                scanf("%d", &val);
                push(stk,val);
                break;
            }
            case 2:
            {
                val=pop(stk);
                if(val!=-1)
                {
                    printf("The value deleted from the stack is: %d\n", val);
                }
                break;
            }
            case 3:
            {
                display(stk);
                break;
            }
            case 4:
            {
                printf("The program has ended.\n");
                exit(0);
            }
            default:
                printf("Invalid choice!\n");
        }
        printf("Do you want to continue?(y/n): ");
        scanf("%s",&x);
    } while(x=='y'||x=='Y');
}
void push(int stk[], int val)
{
    if(top==MAX-1)
    {
        printf("Stack Overflow\n");
    }
    else
    {
        top=top+1;
        stk[top]=val;
    }
}
int pop(int stk[])
{
    int val;
    if (top==-1)
    {
        printf("Stack Underflow\n");
        return -1;
    }
    else
    {
        val=stk[top];
        top=top-1;
        return val;
    }
}
void display(int stk[])
{
    int i;
    if (top==-1)
    {
        printf("Stack is Empty.\n");
    }
    else
    {
        for (i=top;i>=0;i--)
        {
            printf("%d\t",stk[i]);
        }
        printf("\n");
    }
}


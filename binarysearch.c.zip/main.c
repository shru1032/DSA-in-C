/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

//Binary Search
#include <stdio.h>
int main()
{
    int i,n,arr[100],val,flag=0;
    printf("Enter the length of the array: ");
    scanf("%d", &n);
    printf("Enter the elements of the array:\n");
    for (i=0;i<n;i++)
    {
        printf("Enter the element-%d of the array: ",i+1);
        scanf("%d", &arr[i]);
    }
    printf("The array is: \n");
    for (i=0;i<n;i++)
    {
        printf("%d\t", arr[i]);
    }
    printf("\nEnter element to be searched: ");
    scanf("%d", &val);
    int lb=0;
    int ub=n-1;
    int mid;
    
    while (lb<=ub)
    {
        mid= lb + (ub-lb)/2;
        if(arr[mid]<val)
        {
            lb=mid+1;
        }
        else if(arr[mid]>val)
        {
            ub=mid-1;
        }
        else if(arr[mid]==val)
        {
            printf("Value found at index %d and position %d.", mid, mid+1);
            flag=1;
            break;
        }
    }
    if (flag==0)
    {
        printf("Element not found!");
    }

}


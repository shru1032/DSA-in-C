/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

//Program to implement queue operations using a Singly Linked List.

#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include <string.h>

struct queue
{
    int data;
    struct queue *next;
};

struct queue *NN, *rear=NULL, *front=NULL, *temp, *temp2;

void enqueue()
{
    int val;
    int ch;

    printf("Enter data: ");
    scanf("%d", &val);
    NN=(struct queue *)malloc(sizeof(struct queue *));
    NN->data=val;
    NN->next=NULL;
    if (rear==NULL)
    {
        front=rear=NN;
    }
    else
    {
        rear->next=NN;
        rear=NN;
    }
}

int dequeue()
{
    if (front==NULL)
    {
        printf("The queue is empty\n");
    }
    else
    {
        temp=front;
        front=front->next;
        printf("Number dequeued is: %d\n", temp->data);
        free(temp);
    }
}

void display()
{
    int i;
    if (rear==NULL)
    {
        printf("Queue is empty\n");
    }
    else
    {
        temp=front;
        while (temp!=rear)
        {
            printf("%d -> ", temp->data);
            temp=temp->next;
        }
        printf("%d -> ",rear->data);
        printf("\n");
    }
}

void main()
{
    int choice, ch;
    do
    {
        printf("-----Main Menu-----\n");
        printf("1. enQueue\n");
        printf("2. deQueue\n");
        printf("3. Display\n");
        printf("4. Exit\n");
        printf("Enter your choice here: ");
        scanf("%d", &choice);
        switch (choice)
        {
            case 1:
            {
                int chpush;
                do
                {
                    enqueue();
                    printf("Press 1 to enQueue more elements: ");
                    scanf("%d", &chpush);
                }while(chpush==1);
                break;
            }
            case 2:
            {
                dequeue();
                break;
            }
            case 3:
            {
                display();
                break;
            }
            case 4:
            {
                printf("The program has ended\n");
                exit(0);
            }
            default:
            {
                printf("Please enter a valid choice\n");
                break;
            }
        }
        printf("Press 1 to continue: ");
        scanf("%d", &ch);
    }while (ch==1);
}

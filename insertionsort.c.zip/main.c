/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include <string.h>

void swap(int *a, int *b)
{
    int temp;
    temp = *a;
    *a = *b;
    *b = temp;
}

void printarr(int arr[], int size)
{
    int i;
    for (i=0;i<size;i++)
    {
        if (arr[i]==1)
        {
            printf("A ");
        }
        else if (arr[i]==11)
        {
            printf("J ");
        }
        else if (arr[i]==12)
        {
            printf("Q ");
        }
        else if (arr[i]==13)
        {
            printf("K ");
        }
        else
        {
            printf("%d ", arr[i]);
        }
    }
    printf("\n");
}

void insertion_sort(int arr[], int n, int steps)
{
    int i, key, j;
    for (i=0;i<n;i++)
    {
        key=arr[i];
        j=i-1;
        
        while(j>=0 && arr[j]>key)
        {
            arr[j+1]=arr[j];
            j=j-1;
        }
        arr[j+1]=key;
        steps++;
        printarr(arr, n);
    }
    printf("Number of steps: %d\n", steps);
}

int main()
{
    int steps=0;
    //Cards in random order
    int arr[] = {5,2,3,7,4,1,6,10,9,8,11,13,12};
    int n= sizeof(arr)/sizeof(arr[0]);
    insertion_sort(arr,n,steps);
    printarr(arr, n);
    return 0;
}
/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/
//Menu-driven program to implement double ended queue.

#include <stdio.h>
#include <conio.h>
#include <stdlib.h>
#define MAX 20

int queue[MAX];
int front=-1, rear=-1;

void insertfront(int val);
void insertend(int val);
int deletefront();
int deleteend();
void display();

void main()
{
    int ch, choice;
    do{
        printf("--------Main Menu--------\n");
        printf("1. Insert at front\n");
        printf("2. Insert at end\n");
        printf("3. Delete from front\n");
        printf("4. Delete from end\n");
        printf("5. Display\n");
        printf("6. Exit\n");
        printf("Enter your choice here: ");
        scanf("%d", &choice);
        switch (choice)
        {
            case 1:
            {
                int val;
                printf("Enter number to be inserted: ");
                scanf("%d", &val);
                insertfront(val);
                break;
            }
            case 2:
            {
                int val;
                printf("Enter number to be inserted: ");
                scanf("%d", &val);
                insertend(val);
                break;
            }
            case 3:
            {
                deletefront();
                break;
            }
            case 4:
            {
                deleteend();
                break;
            }
            case 5:
            {
                printf("The elements of the queue are:\n");
                display();
                break;
            }
            case 6:
            {
                printf("The program has ended\n");
                exit(0);
            }
            default:
            {
                printf("Please enter a valid choice.\n");
                break;
            }
        }
        printf("Press 1 to continue.\n");
        scanf("%d", &ch);
    } while (ch==1);
}

void insertfront(int val)
{
    int i;
    if (front==0 && rear==MAX-1)
    {
        printf("Queue Overflow\n");
    }
    else if(front>rear)
    {
        front=rear=-1;
    }
    else if (front==-1)
    {
        front=0;
        rear=0;
        queue[front]=val;
    }
    else
    {
        rear++;
        queue[rear]=queue[rear-1];
        for(i=rear-1;i>=front;i--)
        {
            queue[i]=queue[i-1];
        }
        queue[front]=val;
    }
}

void insertend(int val)
{
    int i;
    if (front==0 && rear==MAX-1)
    {
        printf("Queue Overflow\n");
    }
    else if(front>rear)
    {
        front=rear=-1;
    }
    else if (front==-1)
    {
        front=0;
        rear=0;
        queue[rear]=val;
    }
    else
    {
        rear++;
        queue[rear]=val;
    }
}

int deletefront()
{
    if ((front==-1 && rear==-1)||(front>rear))
    {
        printf("Queue Underflow\n");
    }
    else
    {
        printf("Number deleted from the queue is: %d\n", queue[front]);
        front++;
    }
}

int deleteend()
{
    if ((front==-1 && rear==-1)||(front>rear))
    {
        printf("Queue Underflow\n");
    }
    else
    {
        printf("Number deleted from the queue is: %d\n", queue[rear]);
        rear--;
    }
}

void display()
{
    int i;
    if ((front==-1 && rear==-1)||(front>rear))
    {
        printf("Queue is empty\n");
    }
    else
    {
        for (i=front;i<=rear;i++)
        {
            printf("%d\t",queue[i]);
        }
    }
    printf("\n");
}


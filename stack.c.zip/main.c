/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/
#include <stdio.h>
#define MAX 100
char stack[MAX],top=-1;

void push(char val)
{
    if (top==MAX-1)
    {
        printf("\n Stack Overflow");
    }
    else
    {
        top=top+1;
        stack[top]=val;
    }
}
void display()
{
    int i;
    for(i=0;i<=top;i++)
    {
        printf("%c\t", stack[i]);
    }
}
void pop()
{
    if(top==-1)
    {
        printf("\n Stack Underflow");
    }
    else
    {
        printf("Deleted element is: %c\n", stack[top]);
        top=top-1;
    }
}

void main()
{
    push('a');
    push('b');
    push('c');
    push('d');
    push('e');
    push('f');
    pop();
    pop();
    push('g');
    push('h');
    pop();
    pop();
    pop();
    pop();
    push('i');
    display();
}

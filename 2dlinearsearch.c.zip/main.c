/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>
int LinearSearch(int arr[10][10], int x, int y, int n);
void main()
{
    int arr[10][10], x,y,n,i,j;
    printf("Enter the number of rows:");
    scanf("%d", &x);
    printf("Enter the number of columns:");
    scanf("%d", &y);
    for (i=0;i<x;i++)
    {
        for (j=0;j<y;j++)
        {
            printf ("Enter the element at position %d, %d: ", i,j);
            scanf("%d", &arr[i][j]);
        }
    }
    printf("Array is:\n");
    for (i=0;i<x;i++)
    {
        for (j=0;j<y;j++)
        {
            printf("%d\t", arr[i][j]);
        }
        printf("\n");
    }
    printf("Enter element to be searched: ");
    scanf("%d", &n);
    LinearSearch(arr,x,y,n);
    
}

int LinearSearch(int arr[10][10], int x, int y, int n)
{
    int i,j,flag=0;
    for(i=0;i<x;i++)
    {
        for(j=0;j<y;j++)
        {
            if (arr[i][j]==n)
            {
                flag=1;
                printf("Element found at index: %d,%d\n", i,j);
            }
            
        }
    }
    if (flag==0)
        printf("Element not found!");
    return 0;
}


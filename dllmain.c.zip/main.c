/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

//Menu-driven program to impement a Doubly Linked List.

#include <stdio.h>
#include <stdlib.h>

struct node
{
    struct node *prev;
    int data;
    struct node *next;
};

struct node *start=NULL, *current, *NN, *temp, *temp2, *temp3;

void display()
{
    if (start==NULL)
    {
        printf("List is empty\n");
    }
    else
    {
        temp=start;
        printf("Elements of DLL: ");
        while(temp!=NULL)
        {
            printf("%d -> ", temp->data);
            temp=temp->next;
        }
        printf("\n");
    }
}

void create()
{
    int ch, val;
    do{
        printf("Enter the number: ");
        scanf("%d", &val);
        
        NN=(struct node *)malloc(sizeof(struct node *));
        NN->data=val;
        NN->prev=NULL;
        NN->next=NULL;
        
        if (start==NULL)
        {
            start=NN;
            current=NN;
        }
        else
        {
            current->next=NN;
            NN->prev=current;
            current=NN;
        }
        printf("Enter 0 to stop creation: ");
        scanf("%d", &ch);
    }while (ch!=0);
}

void insertbegin(int val)
{
    NN=(struct node*)malloc(sizeof(struct node*));
    NN->prev=NULL;
    NN->data=val;
    NN->next=NULL;
    
    if (start==NULL)
    {
        start=NN;
        current=NN;
    }
    else
    {
        start->prev=NN;
        NN->next=start;
        start=NN;
    }
}

void insertbefore(int val)
{
    NN=(struct node*)malloc(sizeof(struct node*));
    NN->prev=NULL;
    NN->data=val;
    NN->next=NULL;
    
    if (start==NULL)
    {
        start=NN;
        current=NN;
    }
    else
    {
        int n;
        printf("Enter number to insert before: ");
        scanf("%d", &n);
        
        if (start->data==n)
        {
            insertbegin(val);
        }
        else
        {
            temp=start;
            while(temp->data!=n)
            {
                temp=temp->next;
            }
            temp2=temp->prev;
            NN->next=temp;
            NN->prev=temp2;
            temp2->next=NN;
            temp->prev=NN;
        }
    }
}

void insertlast(int val)
{
    NN=(struct node*)malloc(sizeof(struct node*));
    NN->prev=NULL;
    NN->data=val;
    NN->next=NULL;
    
    if (start==NULL)
    {
        start=NN;
        current=NN;
    }
    else
    {
        current->next=NN;
        NN->prev=current;
        current=current->next;
    }
}

void insertafter(int val)
{
    NN=(struct node*)malloc(sizeof(struct node*));
    NN->prev=NULL;
    NN->data=val;
    NN->next=NULL;
    
    if (start==NULL)
    {
        start=NN;
        current=NN;
    }
    else
    {
        int n;
        printf("Enter number to insert after: ");
        scanf("%d", &n);
        
        if (current->data==n)
        {
            insertlast(val);
        }
        else
        {
            temp=start;
            while(temp->data!=n)
            {
                temp=temp->next;
            }
            temp2=temp->next;
            NN->prev=temp;
            NN->next=temp2;
            temp2->prev=NN;
            temp->next=NN;
        }
    }
}

void deletebegin()
{
    if (start==NULL)
    {
        printf("The linked list is empty\n");
    }
    else
    {
        temp=start;
        start=start->next;
        free(temp);
    }
}

void deletemid()
{
    if (start==NULL)
    {
        printf("The linked list is empty\n");
    }
    else
    {
        int n;
        printf("Enter number to be deleted: ");
        scanf("%d", &n);
        
        temp=start;
        while(temp->data!=n)
        {
            temp=temp->next;
        }
        temp2=temp->prev;
        temp3=temp->next;
        temp2->next=temp3;
        temp3->prev=temp2;
        free(temp);
    }
}

void deleteend()
{
    if (start==NULL)
    {
        printf("The linked list is empty\n");
    }
    else
    {
        temp=start;
        while(temp->next!=NULL)
        {
            temp=temp->next;
        }
        
        temp2=temp->prev;
        temp2->next=NULL;
        free(temp);
    }
}

void main()
{
    int choice, ch;
    do
    {
        printf("------Main Menu------\n");
        printf("1. Create DLL\n");
        printf("2. Insert\n");
        printf("3. Delete\n");
        printf("4. Display\n");
        printf("5. Exit\n");
        printf("Enter your choice here: ");
        scanf("%d", &choice);
        switch (choice)
        {
            case 1:
            {
                create();
                break;
            }
            case 2:
            {
                int n;
                printf("Menu:\n");
                printf("1. Insert at beginning\n");
                printf("2. Insert before\n");
                printf("3. Insert after\n");
                printf("4. Insert at last\n");
                printf("Enter your choice: ");
                scanf("%d", &n);
                int val;
                printf("Enter the number to be inserted: ");
                scanf("%d", &val);
                switch(n)
                {
                    case 1:
                    {
                        insertbegin(val);
                        break;
                    }
                    case 2:
                    {
                        insertbefore(val);
                        break;
                    }
                    case 3:
                    {
                        insertafter(val);
                        break;
                    }
                    case 4:
                    {
                        insertlast(val);
                        break;
                    }
                    default:
                    {
                        printf("Please enter a valid choice\n");
                        break;
                    }
                }
                break;
            }
            case 3:
            {
                int n;
                printf("Menu:\n");
                printf("1. Delete from beginning\n");
                printf("2. Delete from middle\n");
                printf("3. Delete from last\n");
                printf("Enter your choice: ");
                scanf("%d", &n);
                int val;
                switch(n)
                {
                    case 1:
                    {
                        deletebegin(val);
                        break;
                    }
                    case 2:
                    {
                        deletemid(val);
                        break;
                    }
                    case 3:
                    {
                        deleteend(val);
                        break;
                    }
                    default:
                    {
                        printf("Please enter a valid choice\n");
                        break;
                    }
                }
                break;
            }
            case 4:
            {
                display();
                break;
            }
            case 5:
            {
                printf("The program has ended\n");
                exit(0);
            }
            default:
            {
                printf("Please enter a valid choice\n");
                break;
            }
        }
        printf("Press 1 to continue: ");
        scanf("%d", &ch);
    }while (ch==1);
}

/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

//Menu-driven program for performing array operations.
#include <stdio.h>

void insertBegin(int arr[100], int n);
void insertBefore(int arr[100],int n);
void insertAt(int arr[100],int n);
void insertAfter(int arr[100],int n);
void del(int arr[100],int n);
void traverse(int arr[100], int n);

void main()
{
    int n, arr[100];
    printf("Enter the length of the array: ");
    scanf("%d", &n);
    printf("Enter the array elements:\n");
    for(int i=0;i<n;i++)
    {
        printf("Enter the element-%d of the array: ",i+1);
        scanf("%d", &arr[i]);
    }
    printf("The array is:\n");
    for(int i=0;i<n;i++)
    {
        printf("%d\t", arr[i]);
    }
    printf("\nPerforming operations on entered array:\n");
    printf("1. Insertion\n");
    printf("2. Deletion\n");
    printf("3. Traversing\n");
    printf("4. Exit\n");
    int choice;
    printf("Enter your choice here: ");
    scanf("%d", &choice);
    switch(choice)
    {
        case 1: 
        {
            int ch;
            printf("Insering options:\n");
            printf("1. Insert at the beginning of the array\n");
            printf("2. Insert before the entered index of the array\n");
            printf("3. Insert at the entered index\n");
            printf("4. Insert after the entered index of the array\n");
            printf("Enter your choice here: ");
            scanf("%d",&ch);
            switch(ch)
            {
                case 1: insertBegin(arr,n);break;
                case 2: insertBefore(arr,n);break;
                case 3: insertAt(arr,n);break;
                case 4: insertAfter(arr,n);break;
            }
            break;
        }
        case 2: del(arr,n); break;
        case 3: traverse(arr,n); break;
        case 4:
        {
            printf("The program has ended!");
            break;
        }
    }
}
//Function to insert an element at the beginning of the array
void insertBegin(int arr[100], int n)
{
    int i;
    int num;
    printf("Enter the number to be inserted: ");
    scanf("%d",&num);
    n++;
    for(i=n-1;i>0;i--)
    {
        arr[i]=arr[i-1];
    }
    arr[0]=num;
    printf("The array after insertion is: \n");
    for(i=0;i<n;i++)
    {
        printf("%d\t", arr[i]);
    }
}
//Function to insert an element before the specific index of the array
void insertBefore(int arr[100],int n)
{
    int a,i;
    printf("Enter the index to insert a number before it: ");
    scanf("%d", &a);
    int num;
    printf("Enter the number to be inserted: ");
    scanf("%d",&num);
    n++;
    for(i=n-1;i>=a;i--)
    {
        arr[i]=arr[i-1];
    }
    arr[a]=num;
    printf("The array after insertion is: \n");
    for(i=0;i<n;i++)
    {
        printf("%d\t", arr[i]);
    }
}
//Function to insert an element at the specified index of the array
void insertAt(int arr[100],int n)
{
    int a,i;
    printf("Enter the index to insert a number: ");
    scanf("%d", &a);
    int num;
    printf("Enter the number to be inserted: ");
    scanf("%d",&num);
    n++;
    for(i=n-1;i>=a;i--)
    {
        arr[i]=arr[i-1];
    }
    arr[a]=num;
    printf("The array after insertion is: \n");
    for(i=0;i<n;i++)
    {
        printf("%d\t", arr[i]);
    }
}
//Function to insert an element after the specified index of the array
void insertAfter(int arr[100],int n)
{
    int a,i;
    printf("Enter the index to insert a number after it: ");
    scanf("%d", &a);
    int num;
    printf("Enter the number to be inserted: ");
    scanf("%d",&num);
    n++;
    for(i=n-1;i>a+1;i--)
    {
        arr[i]=arr[i-1];
    }
    arr[a+1]=num;
    printf("The array after insertion is: \n");
    for(i=0;i<n;i++)
    {
        printf("%d\t", arr[i]);
    }
}
//Function to delete an element from the array
void del(int arr[100],int n)
{
    int a,i;
    printf("Enter the index to delete element: ");
    scanf("%d", &a);
    if (a<n)
    {
        for(int j=a;j<n-1;j++)
        {
            arr[j]=arr[j+1];
        }
        printf("The array after deletion is: \n");
        for(int k=0;k<n-1;k++)
        {
            printf("%d\t", arr[k]);
        }
    }
    else
        printf("Deletion is not possible!");
}
// Function to traverse the array elements
void traverse(int arr[100], int n)
{
    printf("The elements of the array are:\n");
    for (int i=0;i<n;i++)
    {
        printf("%d\n", arr[i]);
    }
    printf("End of array!");
}
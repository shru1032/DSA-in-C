/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/


//To perform basic arithmetic operations on a matrix. 
#include <stdio.h>

int add(int arr1[20][20], int[20][20], int r, int c);
int sub(int arr1[20][20], int arr2[20][20], int r, int c);
int mult(int arr1[20][20], int arr2[20][20], int r, int c, int c2);
int transpose(int arr1[20][20], int r, int c);

int main()
{
    int arrA[20][20], arrB[20][20]; 
    int i1,j1,r1,c1;
    int i2,j2,r2,c2;
    printf("Enter the number of rows in matrix A: ");
    scanf("%d", &r1);
    printf("Enter the number of columns in matrix A: ");
    scanf("%d", &c1);
    
    //To take array A as input
    for(i1=0;i1<r1;i1++)
    {
        for(j1=0;j1<c1;j1++)
        {
            printf("Enter the %d, %d element of the array: ",i1,j1);
            scanf("%d", &arrA[i1][j1]);
        }
    }
    
    //To display array A
    printf("The A matrix is:\n");
    for(i1=0;i1<r1;i1++)
    {
        for(j1=0;j1<c1;j1++)
        {
            printf("%d\t",arrA[i1][j1]);
        }
        printf("\n");
    }
    
    printf("Enter the number of rows in matrix B: ");
    scanf("%d",&r2);
    printf("Enter the number of columns in matrix B: ");
    scanf("%d",&c2);
    
    //To take array B as input
    for(i2=0;i2<r2;i2++)
    {
        for(j2=0;j2<c2;j2++)
        {
            printf("Enter the %d, %d element of the array: ", i2,j2);
            scanf("%d",&arrB[i2][j2]);
        }
    }
    
    //To display array B
    printf("The B matrix is:\n");
    for(i2=0;i2<r2;i2++)
    {
        for(j2=0;j2<c2;j2++)
        {
            printf("%d\t",arrB[i2][j2]);
        }
        printf("\n");
    }
    
    //Menu of operations using switch case.
    printf("\n");
    int n;
    printf("Performing basic arithmetic and matrix operations on arrays.\n");
    printf("Arithmetic Operations: \n");
    printf("1. Addition\n");
    printf("2. Subtraction\n");
    printf("3. Multiplication\n");
    printf("4. Transpose\n");
    printf("5. Exit\n");
    printf("Enter your choice here: ");
    scanf("%d",&n);
    switch(n)
    {
        case 1:
        {
            if (r1==r2 && c1==c2)
            {
                add(arrA,arrB,r1,c1);
            }
            else
            {
                printf("The two matrices are of different order.");
            }
            break;
        }
        case 2:
        {
            if (r1==r2 && c1==c2)
            {
                sub(arrA,arrB,r1,c1);
            }
            else
            {
                printf("The two matrices are of different order.");
            }
            break;
        }
        case 3:
        {
            if (c1==r2)
            {
                mult(arrA,arrB,r1,c1,c2);
            }
            else
            {
                printf("The 2 matrices cannot be multiplied.");
            }
            break;
        }
        case 4:
        {
            char s;
            printf("Enter matrix name to find transpose (A/B): ");
            scanf("%s", &s);
            switch(s)
            {
                case 'A' :
                {
                    transpose(arrA,r1,c1);
                    break;
                }
                case 'B' :
                {
                    transpose(arrB,r2,c2);
                    break;
                }
            }
            break;
        }
        case 5:
        {
            printf("The program has ended.");
            break;
        }
    }
    return 0;
}

//To find the sum of 2 matrices
int add(int arr1[20][20], int arr2[20][20], int r, int c)
{
    
    printf("\nAddition of the 2 matrices is:\n");
    int arr3[20][20];
    int i,j;
    for(i=0;i<r;i++)
    {
        for(j=0;j<c;j++)
        {
            arr3[i][j]=arr1[i][j]+arr2[i][j];
            printf("%d\t",arr3[i][j]);
        }
        printf("\n");
    }
    return 0;
}

//To find the difference of 2 matrices
int sub(int arr1[20][20], int arr2[20][20], int r, int c)
{
    
    printf("\nAddition of the 2 matrices is:\n");
    int arr3[20][20];
    int i,j;
    for(i=0;i<r;i++)
    {
        for(j=0;j<c;j++)
        {
            arr3[i][j]=arr1[i][j]-arr2[i][j];
            printf("%d\t",arr3[i][j]);
        }
        printf("\n");
    }
    return 0;
}

//To find the product of 2 matrices 
int mult(int arr1[20][20], int arr2[20][20], int r, int c, int c2)
{
    
    printf("\nMultiplication of the 2 matrices is:\n");
    int arr3[20][20];
    int i,j,k;
    for(i=0;i<r;i++)
    {
        for(j=0;j<c;j++)
        {
            for(k=0;k<c2;k++)
            {
                arr3[i][j]=arr3[i][j]+(arr1[i][k]*arr2[k][j]);
            }
        }
    }
    for(i=0;i<r;i++)
    {
        for(j=0;j<c2;j++)
        {
            printf("%d\t",arr3[i][j]);
        }
        printf("\n");
    }
    return 0;
}

//To find the transpose of matrix A or B
int transpose(int arr1[20][20],int r, int c)
{
    printf("\nTranspose of the matrix is:\n");
    int arr2[20][20];
    int i,j;
    for(i=0;i<c;i++)
    {
        for(j=0;j<r;j++)
        {
            arr2[i][j]=arr1[j][i];
        }
    }
    for(i=0;i<c;i++)
    {
        for(j=0;j<r;j++)
        {
            printf("%d\t",arr2[i][j]);
        }
        printf("\n");
    }
    return 0;
}



/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

/*2 stack array*/

#include <stdio.h>
#include <conio.h>
#include <stdlib.h>
#define MAX 5
int stack[MAX],topA=-1,topB=MAX;
void pushA(int val)
{
    if (topB-topA==1)
    {
        printf("Stack is overflow");
    }
    else
    {
        topA++;
        stack[topA]=val;
    }
}
void pushB(int val)
{
    if (topB-topA==1)
    {
        printf("Stack is overflow");
    }
    else
    {
        topB=topB-1;
        stack[topB]=val;
    }
}
int popA()
{
    if (topA==-1)
    {
        printf("Stack A is empty\n");
    }
    else
    {
        return stack[topA];
        topA=topA-1;
    }
}
int popB()
{
    if (topB==MAX)
    {
        printf("Stack B is empty\n");
    }
    else
    {
        return stack[topB];
        topB=topB+1;
    }
}
void display()
{
    printf("\nElements of Stack A are:\n");
    for(int i=0;i<=topA;i++)
    {
        printf("%d\t",stack[i]);
    }
    printf("\nElements of Stack B are:\n");
    for(int j=MAX-1;j>=topB;j--)
    {
        printf("%d\t",stack[j]);
    }
    printf("\nElements of array are:\n");
    for(int k=0;k<=MAX-1;k++)
    {
        printf("%d\t",stack[k]);
    }
}
void main()
{
    char s;
    do{
        int ch;
        printf("/////// Main Menu ///////\n");
        printf("1. Push into stack A\n");
        printf("2. Push into stack B\n");
        printf("3. Pop from stack A\n");
        printf("4. Pop from stack B\n");
        printf("5. Display the elements of stacks and array\n");
        printf("6. Exit\n");
        printf("Enter your choice here: ");
        scanf("%d",&ch);
        switch(ch)
        {
            case 1:
            {
                int a;
                printf("Enter the number to be pushed in stack A: ");
                scanf("%d", &a);
                pushA(a);
                break;
            }
            case 2:
            {
                int a;
                printf("Enter the number to be pushed in stack B: ");
                scanf("%d", &a);
                pushB(a);
                break;
            }
            case 3:
            {
                printf("The number deleted from stack A is: %d\n",popA());
                break;
            }
            case 4:
            {
                printf("The number deleted from stack B is: %d\n",popB());
                break;
            }
            case 5:
            {
                display();
                printf("\n");
                break;
            }
            case 6:
            {
                printf("The program has ended.\n");
                exit(0);
            }
            default:
            {
                printf("Invalid choice!\n");
            }
        }
        printf("Do you want to continue?(y/n): ");
        scanf("%s",&s);
    } while (s=='y'||s=='Y');
}



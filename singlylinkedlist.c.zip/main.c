/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

//Menu-driven program to implement singly linked list.

#include <stdio.h>
#include <stdlib.h>
    
struct node 
{
    int data;
    struct node *next;
};

struct node *start=NULL, *temp, *NN, *current, *temp2, *temp3;

void create()
{
    int n,ch;
    do{
        printf("Enter the data: ");
        scanf("%d", &n);
        NN = (struct node *)malloc(sizeof(struct node *));
        NN->data=n;
        NN->next=NULL;
        if (start==NULL)
        {
            start=NN;
            current=NN;
        }
        else
        {
            current->next=NN;
            current=NN;
        }
        printf("Press 0 to stop creation: ");
        scanf("%d",&ch);
    }while(ch!=0);
}

void display()
{
    if (start==NULL)
    {
        printf("No elements in the list\n");
    }
    else
    {
    temp=start;
    while (temp!=NULL)
    {
        printf("%d -> ",temp->data);
        temp=temp->next;
    }
    printf("\n\n");
    }
}

void insertbegin(int val)
{
    NN = (struct node *)malloc(sizeof(struct node *));
    NN->data=val;
    NN->next=NULL;
    
    if (start==NULL)
    {
       start=NN;
       current=NN;
    }
    else
    {
        NN->next=start;
        start=NN;
    }
}

void insertafter(int val)
{
    int i,n;
    NN = (struct node *)malloc(sizeof(struct node *));
    NN->data=val;
    NN->next=NULL;
    
    if (start==NULL)
    {
       start=NN;
       current=NN;
    }
    else
    {
        temp=start;
        printf("Enter number to insert after: ");
        scanf("%d", &n);
        while(temp->data!=n)
        {
            temp=temp->next;
        }
        temp2=temp->next;
        temp->next=NN;
        NN->next=temp2;
    }
}

void insertbefore(int val)
{
    int i,n;
    NN = (struct node *)malloc(sizeof(struct node *));
    NN->data=val;
    NN->next=NULL;
    
    if (start==NULL)
    {
       start=NN;
       current=NN;
    }
    else
    {
        temp=start;
        printf("Enter number to insert before: ");
        scanf("%d", &n);
        while(temp->data!=n)
        {
            temp2=temp;
            temp=temp->next;
        }
        temp2->next=NN;
        NN->next=temp;
    }
}

void insertend(int val)
{
    int i;
    NN = (struct node *)malloc(sizeof(struct node *));
    NN->data=val;
    NN->next=NULL;
    
    if (start==NULL)
    {
       start=NN;
       current=NN;
    }
    else
    {
        temp=start;
        while(temp->next!=NULL)
        {
            temp=temp->next;
        }
        temp2=temp->next;
        temp->next=NN;
        NN->next=temp2;
    }
}

void deletestart()
{
    printf("Number deleted from SLL is: %d\n", start->data);
    if (start==current)
    {
        start=NULL;
        current=NULL;
    }
    else
    {
        start=start->next;
    }
}

void deleteend()
{
    temp=start;
    while(temp->next!=NULL)
    {
        temp2=temp;
        temp=temp->next;
    }
    printf("Number delete from SLL is: %d\n", temp->data);
    free(temp);
    temp2->next=NULL;
    current=temp2;
}

void deletebefore()
{
    int val;
    if (start==current)
    {
        start=NULL;
        current=NULL;
    }
    else
    {
        printf("Enter value to delete element before it: ");
        scanf("%d", &val);
        
        temp=start;
    
        while(temp->data!=val)
        {
            temp2=temp;
            temp=temp->next;
        }
        temp=start;
        temp3=start;
        while(temp3!=temp2)
        {
            temp=temp3;
            temp3=temp3->next;
        }
        temp2=temp3->next;
        temp->next=temp2;
        printf("Number deleted from SLL is: %d\n", temp3->data);
        free(temp3);
    }
}

void deleteafter()
{
    int val;
    if (start==current)
    {
        start=NULL;
        current=NULL;
    }
    else
    {
        printf("Enter value to delete element after it: ");
        scanf("%d", &val);
        
        temp=start;
    
        while(temp->data!=val)
        {
            temp=temp->next;
        }
        temp2=temp->next;
        temp->next=temp2->next;
        printf("Number deleted from SLL is: %d\n", temp2->data);
        free(temp2);
    }
}

void main()
{
    int choice, ch;
    do{
        printf("-----MAIN MENU------\n");
        printf("1. Create SLL\n");
        printf("2. Insert at beginning\n");
        printf("3. Insert in the middle\n");
        printf("4. Insert at the last\n");
        printf("5. Delete from beginning\n");
        printf("6. Delete from the middle\n");
        printf("7. Delete from the last\n");
        printf("8. Display SLL\n");
        printf("9. Exit\n");
        printf("Enter your choice here: ");
        scanf("%d", &choice);
        switch(choice)
        {
            case 1:
            {
                create();
                break;
            }
            case 2:
            {
                int val;
                printf("Enter number to be inserted in the beginning: ");
                scanf("%d", &val);
                insertbegin(val);
                break;
            }
            case 3:
            {
                int x, val;
                printf("3.1. Insert before\n");
                printf("3.2. Insert after\n");
                printf("Enter your choice: ");
                scanf("%d", &x);
                switch(x)
                {
                    case 1: 
                    {
                        printf("Enter number to be inserted: ");
                        scanf("%d", &val);
                        insertbefore(val);
                        break;
                    }
                    case 2:
                    {
                        printf("Enter number to be inserted: ");
                        scanf("%d", &val);
                        insertafter(val);
                        break;
                    }
                    default:
                    {
                        printf("Invalid choice\n");
                        break;
                    }
                }
                break;
            }
            case 4:
            {
                int val;
                printf("Enter number to be inserted in the last: ");
                scanf("%d", &val);
                insertend(val);
                break;
            }
            case 5:
            {
                deletestart();
                break;
            }
            case 6:
            {
                int x;
                printf("6.1. Delete before\n");
                printf("6.2. Delete after\n");
                printf("Enter your choice: ");
                scanf("%d", &x);
                switch(x)
                {
                    case 1: 
                    {
                        deletebefore();
                        break;
                    }
                    case 2:
                    {
                        deleteafter();
                        break;
                    }
                    default:
                    {
                        printf("Invalid choice\n");
                        break;
                    }
                }
                break;
            }
            case 7:
            {
                deleteend();
                break;
            }
            case 8:
            {
                printf("\nElements of the SLL are: \n");
                display();
                break;
            }
            case 9:
            {
                printf("The program has ended.\n");
                exit(0);
            }
            default:
            {
                printf("Please enter a valid choice\n");
                break;
            }
        }
        printf("Press 1 to continue: ");
        scanf("%d", &ch);
    }while (ch==1);
}




/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>

struct node
{
    struct node *prev;
    int data;
    struct node *next;
};

struct node *start=NULL, *current, *NN, *temp, *temp2, *temp3;

void display()
{
    temp=start;
    
    printf("\nElements of DLL: ");
    while(temp!=NULL)
    {
        printf("%d -> ", temp->data);
        temp=temp->next;
    }
}

void create()
{
    int ch, val;
    do{
        printf("\nEnter the number: ");
        scanf("%d", &val);
        
        NN=(struct node *)malloc(sizeof(struct node *));
        NN->data=val;
        NN->prev=NULL;
        NN->next=NULL;
        
        if (start==NULL)
        {
            start=NN;
            current=NN;
        }
        else
        {
            current->next=NN;
            NN->prev=current;
            current=NN;
        }
        printf("\nEnter -1 to stop: ");
        scanf("%d", &ch);
    }while (ch!=-1);
}

void average()
{
    float sum=0;
    int count=0;
    temp=start;
    while(temp!=NULL)
    {
        sum=sum + temp->data;
        temp=temp->next;
        count++;
    }
    printf("\nThe average of numbers in DLL= %f", sum/count);
}

/*void concatenate(struct node *DLL1, struct node *DLL2)
{
    if (DLL1->next==NULL)
    {
        DLL1->next=DLL2;
    }
    else
    {
        concatenate(DLL1->next,DLL2);
    }
}*/

int main()
{
    create();
    display();
    average();
}
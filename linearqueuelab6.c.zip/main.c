/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/

//Menu-driven program to implement linear queue.

#include <stdio.h>
#include <conio.h>
#include <stdlib.h>
#define MAX 20

int front=-1, rear=-1, queue[MAX];

void enQueue(int val);
int deQueue();
void display();

int main()
{
    int choice;
    do
    {
        int ch;
        printf("--------Main Menu---------\n");
        printf("1. enQueue\n");
        printf("2. deQueue\n");
        printf("3. Display\n");
        printf("4. Exit\n");
        printf("Enter your choice here: ");
        scanf("%d", &ch);
        switch(ch)
        {
            case 1:
            {
                int x;
                printf("Enter the value to be added to the queue: ");
                scanf("%d", &x);
                enQueue(x);
                break;
            }
            case 2:
            {
                printf("The element deleted from the queue is: %d\n", deQueue());
                break;
            }
            case 3:
            {
                display();
                break;
            }
            case 4:
            {
                printf("The program has ended.\n");
                exit(0);
            }
            default:
            {
                printf("Please enter a valid choice!\n");
            }
        }
        printf("Press 1 to continue: ");
        scanf("%d", &choice);
    } while (choice==1);
}

void enQueue(int val)
{
    if (rear==MAX-1)
    {
        printf("Queue Overflow\n");
    }
    else if (front==-1 && rear==-1)
    {
        front=0;
        rear=0;
    }
    else
    {
        rear++;
    }
    queue[rear]=val;
}

int deQueue()
{
    int val;
    if (front==-1||front>rear)
    {
        printf("Queue Underflow\n");
        if (front>rear)
        {
            front=-1;
            rear=-1;
        }
        return -1;
    }
    else
    {
        val=queue[front];
        front++;
    }
    return val;
}

void display()
{
    int i;
    if (front==-1||front>rear)
    {
        printf("The queue is empty\n");
    }
    else
    {
        printf("The elements of the queue are:\n");
        for(i=front; i<=rear; i++)
        {
            printf("%d\t", queue[i]);
        }
        printf("\n");
    }
}
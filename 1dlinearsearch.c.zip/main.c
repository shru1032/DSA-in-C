/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>
int LinearSearch(int arr[],int n, int x);
void main()
{
    int arr[100],n,i=0,x;
    printf("Enter the size of the array:");
    scanf("%d",&n);
    for (i=0;i<n;i++)
    {
        printf("Enter the element %d of the array:", i+1);
        scanf("%d", &arr[i]);
    }
    printf("Enter element to be searched:");
    scanf("%d", &x);
    
    int result;
    result = LinearSearch(arr, n, x);
    if (result==0)
    {
        printf("Element not found!");
    }
    else 
    {
        printf("Element found at position: %d", result+1);

    }
}

int LinearSearch(int arr[],int n, int x)
{
    int i;
    for (i=1;i<=n;i++)
    {
        if (arr[i]==x)
        {
            return i;
        }
    }
    return 0;
}

/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include <string.h>

struct tree
{
    struct tree *lst;
    int root;
    struct tree *rst;
};

struct tree *NN, *start=NULL, *current, *temp;

void create()
{
    int val;
    printf("Enter root: ");
    scanf("%d", &val);
    NN=(struct tree *)malloc(sizeof(struct tree *));
    NN->lst=NULL;
    NN->root=val;
    NN->rst=NULL;
    start=NN;
}

void insert()
{
    int val;
    printf("Enter number to be inserted: ");
    scanf("%d", &val);
    NN=(struct tree *)malloc(sizeof(struct tree *));
    NN->lst=NULL;
    NN->root=val;
    NN->rst=NULL;
    if (val<start->root)
    {
        start->lst=NN;
    }
    else
    {
        start->rst=NN;
    }
}

void display()
{
   temp=start;
   while ((temp->lst!=NULL)&&(temp->rst!=NULL))
   {
       printf("%d\t%d\t%d", temp->lst, temp->root, temp->rst);
       temp=temp->lst;
   }
}

void main()
{
    create();
    insert();
    display();
}

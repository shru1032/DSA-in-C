/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/
//Program to reverse an SLL using stacks

#include <stdio.h>
#include <stdlib.h>
#define MAX 100
void push(int val);

struct node 
{
    int data;
    struct node *next;
};

struct node *start=NULL, *temp, *NN, *current, *temp2, *temp3;
int stk[MAX];
int top=-1;

void create()
{
    int n,ch;
    do{
        printf("Enter the data: ");
        scanf("%d", &n);
        NN = (struct node *)malloc(sizeof(struct node *));
        NN->data=n;
        push(n);
        NN->next=NULL;
        if (start==NULL)
        {
            start=NN;
            current=NN;
        }
        else
        {
            current->next=NN;
            current=NN;
        }
        printf("Press 0 to stop creation: ");
        scanf("%d",&ch);
    }while(ch!=0);
}

void display()
{
    if (start==NULL)
    {
        printf("No elements in the list\n");
    }
    else
    {
    temp=start;
    while (temp!=NULL)
    {
        printf("%d -> ",temp->data);
        temp=temp->next;
    }
    printf("\n\n");
    }
}

void push(int val)
{
    if (top==MAX-1)
    {
        printf("Stack Overflow\n");
    }
    else
    {
        top++;
        stk[top]=val;
    }
}

void reverse()
{
    printf("\nReverse of SLL is: \n");
    while(top!=-1)
    {
        printf("%d -> ", stk[top]);
        top--;
    }
    printf("\n");
}

void main()
{
    int choice, ch;
    do{
        printf("----Main Menu----\n");
        printf("1. Create SLL\n");
        printf("2. Display SLL\n");
        printf("3. Display SLL in reverse order\n");
        printf("4. Exit\n");
        printf("Enter your choice here: ");
        scanf("%d", &choice);
        switch(choice)
        {
            case 1:
            {
                create();
                break;
            }
            case 2:
            {
                printf("\nElements of the SLL are:\n");
                display();
                break;
            }
            case 3:
            {
                reverse();
                break;
            }
            case 4:
            {
                printf("The program has ended.\n");
                exit(0);
            }
            default:
            {
                printf("Please enter a valid choice\n");
                break;
            }
        }
        printf("Press 1 to continue: ");;
        scanf("%d", &ch);
    }while (ch==1);
}
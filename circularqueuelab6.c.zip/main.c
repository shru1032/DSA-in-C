/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

//Menu-driven program to implement circular queue.

#include <stdio.h>
#include <conio.h>
#include <stdlib.h>
#define MAX 3

int front=-1, rear=-1, queue[MAX];

void enQueue(int val);
int deQueue();
void display();

int main()
{
    int choice;
    do
    {
        int ch;
        printf("--------Main Menu---------\n");
        printf("1. enQueue\n");
        printf("2. deQueue\n");
        printf("3. Display\n");
        printf("4. Exit\n");
        printf("Enter your choice here: ");
        scanf("%d", &ch);
        switch(ch)
        {
            case 1:
            {
                int x;
                printf("Enter the value to be added to the queue: ");
                scanf("%d", &x);
                enQueue(x);
                break;
            }
            case 2:
            {
                printf("The element deleted from the queue is: %d\n", deQueue());
                break;
            }
            case 3:
            {
                display();
                break;
            }
            case 4:
            {
                printf("The program has ended.\n");
                exit(0);
            }
            default:
            {
                printf("Please enter a valid choice!\n");
            }
        }
        printf("Press 1 to continue: ");
        scanf("%d", &choice);
    } while (choice==1);
}

void enQueue(int val)
{
    if (front==0 && rear==MAX-1)
    {
        printf("Queue Overflow\n");
    }
    else if(front==-1 && rear==-1)
    {
        front=0;
        rear=0;
        queue[rear]=val;
    }
    else if(rear==MAX-1 && front!=0)
    {
        rear=0;
        queue[rear]=val;
    }
    else
    {
        rear++;
        queue[rear]=val;
    }
}

int deQueue()
{
    int val;
    if (front==-1 && rear==-1)
    {
        printf("Queue Underflow\n");
        return -1;
    }
    val=queue[front];
    if (front==rear)
    {
        front=-1;
        rear=-1;
    }
    else
    {
        if (front==MAX-1)
        {
            front=0;
        }
        else
        {
            front++;
        }
    }
    return val;
}

void display()
{
    int i;
    printf("The elements of the queue are:\n");
    if (front==-1 && rear==-1)
    {
        printf("The queue is empty.\n");
    }
    else
    {
        if (front<rear)
        {
            for(i=front;i<=rear;i++)
            {
                printf("%d\t", queue[i]);
            }
            printf("\n");
        }
        else
        {
            for(i=front;i<=MAX-1;i++)
                printf("%d\t", queue[i]);
            for(i=0;i<=rear;i++)
                printf("%d\t", queue[i]);
            printf("\n");
        }
    }
}
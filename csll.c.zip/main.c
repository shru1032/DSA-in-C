/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

//Menu-driven program to implement a Circular Singly Linked List

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

void create();
void insertbegin(int);
void insertbefore(int);
void insertafter(int);
void insertlast(int);
int deletebegin();
int deletemid();
int deletelast();
void display();

struct node 
{
    int data;
    struct node* next;
};

struct node *start=NULL, *current, *NN, *temp, *temp2, *temp3;

void main()
{
    int choice, ch;
    do
    {
        printf("------Main Menu------\n");
        printf("1. Create CSLL\n");
        printf("2. Insert\n");
        printf("3. Delete\n");
        printf("4. Display\n");
        printf("5. Exit\n");
        printf("Enter your choice here: ");
        scanf("%d", &choice);
        switch (choice)
        {
            case 1:
            {
                create();
                break;
            }
            case 2:
            {
                int n;
                printf("Menu:\n");
                printf("1. Insert at beginning\n");
                printf("2. Insert before\n");
                printf("3. Insert after\n");
                printf("4. Insert at last\n");
                printf("Enter your choice: ");
                scanf("%d", &n);
                int val;
                printf("Enter the number to be inserted: ");
                scanf("%d", &val);
                switch(n)
                {
                    case 1:
                    {
                        insertbegin(val);
                        break;
                    }
                    case 2:
                    {
                        insertbefore(val);
                        break;
                    }
                    case 3:
                    {
                        insertafter(val);
                        break;
                    }
                    case 4:
                    {
                        insertlast(val);
                        break;
                    }
                    default:
                    {
                        printf("Please enter a valid choice\n");
                        break;
                    }
                }
                break;
            }
            case 3:
            {
                int n;
                printf("Menu:\n");
                printf("1. Delete from beginning\n");
                printf("2. Delete from middle\n");
                printf("3. Delete from last\n");
                printf("Enter your choice: ");
                scanf("%d", &n);
                int val;
                switch(n)
                {
                    case 1:
                    {
                        deletebegin(val);
                        break;
                    }
                    case 2:
                    {
                        deletemid(val);
                        break;
                    }
                    case 3:
                    {
                        deletelast(val);
                        break;
                    }
                    default:
                    {
                        printf("Please enter a valid choice\n");
                        break;
                    }
                }
                break;
            }
            case 4:
            {
                display();
                break;
            }
            case 5:
            {
                printf("The program has ended\n");
                exit(0);
            }
            default:
            {
                printf("Please enter a valid choice\n");
                break;
            }
        }
        printf("Press 1 to continue: ");
        scanf("%d", &ch);
    }while (ch==1);
}

void create()
{
    int n,ch;
    do{
        printf("Enter the data: ");
        scanf("%d", &n);
        NN = (struct node *)malloc(sizeof(struct node *));
        NN->data=n;
        NN->next=NULL;
        if (start==NULL)
        {
            start=NN;
            current=NN;
        }
        else
        {
            current->next=NN;
            current=NN;
        }
        printf("Press 0 to stop creation: ");
        scanf("%d",&ch);
    }while(ch!=0);
    current->next=start;
}

void insertbegin(int val)
{
    NN = (struct node *)malloc(sizeof(struct node *));
    NN->data=val;
    NN->next=NULL;
    
    if (start==NULL)
    {
       start=NN;
       current=NN;
    }
    else
    {
        NN->next=start;
        start=NN;
    }
}

void insertbefore(int val)
{
    int i,n;
    NN = (struct node *)malloc(sizeof(struct node *));
    NN->data=val;
    NN->next=NULL;
    
    if (start==NULL)
    {
       start=NN;
       current=NN;
    }
    else
    {
        printf("Enter number to insert before: ");
        scanf("%d", &n);
        
        if (start->data!=n)
        {
            temp=start;
            while(temp->data!=n)
            {
                temp2=temp;
                temp=temp->next;
            }
            temp2->next=NN;
            NN->next=temp;
        }
        else
        {
            NN->next=start;
            start=NN;
            current->next=start;
        }
        current->next=start;    
    }
}

void insertafter(int val)
{
    int i,n;
    NN = (struct node *)malloc(sizeof(struct node *));
    NN->data=val;
    NN->next=NULL;
    
    if (start==NULL)
    {
       start=NN;    
       current=NN;
    }
    else
    {
        temp=start;
        printf("Enter number to insert after: ");
        scanf("%d", &n);
        
        if (current->data!=n)
        {
            while(temp->data!=n)
            {
                temp=temp->next;
            }
            temp2=temp->next;
            temp->next=NN;
            NN->next=temp2;
        }
        else
        {
            current->next=NN;
            current=NN;
            current->next=start;
        }
    }
}

void insertlast(int val)
{
    int i;
    NN = (struct node *)malloc(sizeof(struct node *));
    NN->data=val;
    NN->next=NULL;
    
    if (start==NULL)
    {
       start=NN;
       current=NN;
    }
    else
    {
        temp=start;
        while(temp->next!=start)
        {
            temp=temp->next;
        }
        temp2=temp->next;
        temp->next=NN;
        NN->next=temp2;
        current=NN;
        current->next=start;
    }
}

int deletebegin()
{
    if (start==NULL)
    {
        printf("The linked list is empty\n");
    }
    else
    {
        temp=start;
        start=start->next;
        printf("Number deleted from CSLL is: %d\n", temp->data);
        free(temp);
        current->next=start;
    }
    
}

int deletemid()
{
    if (start==NULL)
    {
        printf("The linked list is empty\n");
    }
    else 
    {
        int n;
        printf("Enter number to be deleted: ");
        scanf("%d", &n);
        
        temp=start;
        while (temp->data!=n)
        {
            temp2=temp;
            temp=temp->next;
            temp3=temp->next;
        }
        temp2->next=temp3;
        printf("Element deleted from the CSLL is: %d\n", temp->data);
        free(temp);
    }
}

int deletelast()
{
    if (start==NULL)
    {
        printf("The linked list is empty\n");
    }
    else
    {
        temp=start;
        while(temp->next!=current)
        {
            temp=temp->next;
        }
        printf("Number deleted from CSLL is: %d\n", temp->next->data);
        free(temp->next);
        current=temp;
        current->next=start;
    }
}

void display()
{
    if (start==NULL)
    {
        printf("No elements in the list\n");
    }
    else
    {
        printf("The elements of the list are:\n");
        temp=start;
        while (temp!=current)
        {
            printf("%d -> ",temp->data);
            temp=temp->next;
        }
        printf("%d -> ",current->data);
        printf("%d (start)", start->data);
        printf("\n"); 
    }
}






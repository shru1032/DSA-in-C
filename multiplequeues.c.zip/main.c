/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

//Menu-driven program to implement multiple queues.

#include <stdio.h>
#include <conio.h>
#include <stdlib.h>
#define MAX 20

int arr[MAX];
int front1=-1, rear1=-1;
int front2=MAX, rear2=MAX;

void enQueue1(int val);
void enQueue2(int val);
int deQueue1();
int deQueue2();
void display();

void main()
{
    int ch, choice;
    do{
        printf("--------Main Menu--------\n");
        printf("1. Insert in Queue-1\n");
        printf("2. Insert in Queue-2\n");
        printf("3. Delete from Queue-1\n");
        printf("4. Delete from Queue-2\n");
        printf("5. Display Queue-1 and Queue-2\n");
        printf("6. Exit\n");
        printf("Enter your choice here: ");
        scanf("%d", &choice);
        switch (choice)
        {
            case 1:
            {
                int val;
                printf("Enter number to be inserted in Queue-1: ");
                scanf("%d", &val);
                enQueue1(val);
                break;
            }
            case 2:
            {
                int val;
                printf("Enter number to be inserted in Queue-2: ");
                scanf("%d", &val);
                enQueue2(val);
                break;
            }
            case 3:
            {
                deQueue1();
                break;
            }
            case 4:
            {
                deQueue2();
                break;
            }
            case 5:
            {
                printf("\n");
                display();
                break;
            }
            case 6:
            {
                printf("The program has ended\n");
                exit(0);
            }
            default:
            {
                printf("Please enter a valid choice.\n");
                break;
            }
        }
        printf("Press 1 to continue.\n");
        scanf("%d", &ch);
    } while (ch==1);
}

void enQueue1(int val)
{
    int i;
    if (rear1==rear2-1)
    {
        printf("Queue Overflow\n");
    }
    else if (front1==-1 && rear1==-1)
    {
        front1=0;
        rear1=0;
        arr[rear1]=val;
    }
    else
    {
        rear1++;
        arr[rear1]=val;
    }
}

void enQueue2(int val)
{
    int i;
    if (rear2==rear1+1)
    {
        printf("Queue Overflow\n");
    }
    else if (front2==MAX && rear2==MAX)
    {
        front2=MAX-1;
        rear2=MAX-1;
        arr[rear2]=val;
    }
    else
    {
        rear2--;
        arr[rear2]=val;
    }
}

int deQueue1()
{
    if ((front1==-1 && rear1==-1) || (front1>rear1))
    {
        printf("Queue Underflow\n");
    }
    else
    {
        printf("Number deleted from Queue-1 is: %d\n", arr[front1]);
        front1++;
    }
}

int deQueue2()
{
    if ((front2==MAX && rear2==MAX) || (front2<rear2))
    {
        printf("Queue Underflow\n");
    }
    else
    {
        printf("Number deleted from Queue-2 is: %d\n", arr[front2]);
        front2--;
    }
}

void display()
{
    int i;
    printf("Elements in Queue-1 are:\n");
    if (front1==-1)
    {
        printf("Queue-1 is empty\n");
    }
    else
    {
        for (i=front1;i<=rear1;i++)
        {
            printf("%d\t",arr[i]);
        }
    }
    printf("\n");
    int j;
    printf("Elements in Queue-2 are:\n");
    if (rear2==MAX)
    {
        printf("Queue-2 is empty\n");
    }
    else
    {
        for (j=front2;j>=rear2;j--)
        {
            printf("%d\t",arr[j]);
        }
    }
    printf("\n");
}
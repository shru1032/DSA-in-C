/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <conio.h>
#include <string.h>

void swap(int *a, int *b)
{
    int temp;
    temp = *a;
    *a = *b;
    *b = temp;
}

void printarr(int arr[], int size)
{
    int i;
    for (i=0;i<size;i++)
    {
        if (arr[i]==1)
        {
            printf("A ");
        }
        else if (arr[i]==11)
        {
            printf("J ");
        }
        else if (arr[i]==12)
        {
            printf("Q ");
        }
        else if (arr[i]==13)
        {
            printf("K ");
        }
        else
        {
            printf("%d ", arr[i]);
        }
    }
    printf("\n");
}

void bubble_sort(int arr[], int n, int steps)
{
    int i, j;
    for (i=0;i<n;i++)
    {
        for (j=0;j<i;j++)
        {
            if (arr[j]>arr[j+1])
            {
                swap(&arr[j], &arr[j+1]);
                printarr(arr, n);
                steps++;
            }
        }
    }
    printf("Number of steps: %d\n", steps);
}

int main()
{
    int steps=0;
    //Cards in random order
    int arr[]={5,2,3,7,4,1,6,10,9,8,11,13,12};
    int n = sizeof(arr)/sizeof(arr[0]);
    bubble_sort(arr,n,steps);
    printf("Sorted Cards:\n");
    printarr(arr,n);
    return 0;
}
/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>

void fun(int *arr, int n)
{
    for (int i=0;i<n;i++)
    {
        printf(" %d ",arr[i]*2);
    }
}
int main()
{
    int a[] = {1,2,3,4,5};
    int n=5;
    fun(a,n);
    printf("\n");
    for (int i=0; i<n;i++)
    {
        printf(" %d ", a[i]);
    }
    return 0;
}

/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

//Program to store the names of students in a stack and performing stack operations on it.

#include <stdio.h>
#include <conio.h>
#include <stdlib.h>
#include <string.h>

void push(char name[]);
void pop();
void display();

char stk[100][50]; int top=-1;

int main()
{
    char name[50];
    char s[50];
    int x;
    do{
        int ch;
        printf("----------Main Menu----------\n");
        printf("1. Add a student\n");
        printf("2. Pop a student\n");
        printf("3. Display the list of students\n");
        printf("4. Exit\n");
        printf("Enter your choice here: ");
        scanf("%d", &ch);
        switch(ch)
        {
            case 1:
            {
                printf("Enter the name of the student: ");
                scanf("%s", name);
                push(name);
                break;
            }
            case 2: 
            {
                pop();
                break;
            }
            case 3:
            {
                printf("The list of students is:\n");
                display();
                break;
            }
            case 4:
            {
                printf("The program has ended.\n");
                exit(0);
            }
            default:
            {
                printf("Please enter a valid choice!\n");
                break;
            }
        }
        printf("Press 1 to continue: ");
        scanf("%d", &x);
    } while(x==1);
}

void push(char name[50])
{
    if (top>=100)
    {
        printf("Stack Overflow\n");
    }
    else
    {
        top++;
        strcpy(stk[top], name);
    }
}

void pop()
{
    char s[50];
    if (top==-1)
    {
        printf("Stack Underflow\n");
    }
    else
    {
        top--;
        strcpy(s,stk[top+1]);
    }
    printf("The name of the student popped is: %s\n", s);
}

void display()
{
    int i;
    if (top==-1)
    {
        printf("Stack is empty.\n");
    }
    else
    {
        for (i=0;i<=top;i++)
        {
            printf("%d. %s\n", i+1, stk[i]);
        }
    }
}
